# Ejercicio 1: Lista de nombres

## Objetivo
Practicar el uso de:
- `List<T>`
- Recorrido de listas
- B�squeda de elementos

## Enunciado
Cree una aplicaci�n en **C#** que permita gestionar una lista de nombres de estudiantes.

La aplicaci�n debe cumplir con los siguientes requisitos:

1. Almacenar los nombres de los estudiantes en una `List<string>`.
2. Permitir agregar uno o m�s nombres a la lista.
3. Mostrar en pantalla todos los nombres almacenados.
4. Solicitar un nombre al usuario e indicar si dicho nombre existe o no en la lista.

## Consideraciones
- No utilice LINQ para la b�squeda (use estructuras b�sicas como `foreach` o `for`).
- El programa debe ser ejecutable desde consola.
- El nombre buscado debe compararse correctamente (may�sculas/min�sculas seg�n criterio del estudiante).

## Resultado esperado
El programa debe mostrar mensajes claros al usuario indicando:
- Los nombres almacenados.
- Si el nombre buscado se encuentra o no en la lista.
