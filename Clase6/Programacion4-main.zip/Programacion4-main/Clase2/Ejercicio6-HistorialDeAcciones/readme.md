# Ejercicio 6: Historial de acciones

## Objetivo
Utilizar la colecci�n `Stack<T>` para aplicar el principio LIFO (Last In, First Out).

## Enunciado
Simula un sistema de deshacer acciones (Undo) utilizando una pila, donde la �ltima acci�n registrada es la primera en deshacerse.

El sistema debe permitir las siguientes operaciones:

- Registrar acciones realizadas por el usuario.
- Deshacer la �ltima acci�n registrada.
