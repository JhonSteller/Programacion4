# Ejercicio 5: Turnos de atenci�n

## Objetivo
Utilizar la colecci�n `Queue<T>` para aplicar el principio FIFO (First In, First Out).

## Enunciado
Simula una fila de atenci�n utilizando una cola, donde las personas son atendidas en el mismo orden en que llegan.

La simulaci�n debe permitir las siguientes acciones:

- Agregar personas a la fila de atenci�n.
- Atender a una persona, removi�ndola de la fila seg�n el orden de llegada.
