# Ejercicio 2: Promedio de calificaciones

## Objetivo
Practicar el uso de:
- `List<int>`
- Operaciones b�sicas sobre colecciones
- Recorrido y acumulaci�n de datos

## Enunciado
Cree una aplicaci�n en **C#** que permita trabajar con una lista de calificaciones.

La aplicaci�n debe cumplir con los siguientes requisitos:

1. Generar y almacenar **20 calificaciones** aleatorias entre **0 y 100** en una `List<int>`.
2. Calcular el **promedio** de todas las calificaciones almacenadas.
3. Determinar y mostrar la **calificaci�n mayor** y la **calificaci�n menor** de la lista.

## Restricciones
- No se permite el uso de **LINQ**.
- Las operaciones deben realizarse utilizando estructuras b�sicas como `for` o `foreach`.
- El programa debe ejecutarse desde una aplicaci�n de consola.

## Resultado esperado
El programa debe mostrar en pantalla:
- La lista completa de calificaciones generadas.
- El promedio de las calificaciones.
- La calificaci�n m�s alta y la m�s baja.
