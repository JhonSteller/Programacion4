# Ejercicio 4: Cat�logo de productos

## Objetivo
Utilizar `Dictionary<TKey, TValue>` para almacenar y manipular pares clave�valor.

## Enunciado
Crea un cat�logo de productos utilizando un diccionario, donde:

- El c�digo del producto represente la clave.
- El nombre del producto represente el valor.

El sistema debe permitir las siguientes operaciones:

- Agregar nuevos productos al cat�logo.
- Buscar un producto a partir de su c�digo.
- Eliminar productos del cat�logo utilizando su c�digo.

## Restricci�n
No utilizar LINQ.
