# Ejercicio 3: Ordenamiento seg�n cantidad de letras

## Objetivo
Trabajar con `List<string>` y aplicar operaciones b�sicas sobre colecciones.

## Enunciado
Dada una lista gen�rica que contiene varios nombres, ordenar los elementos de la lista de forma ascendente seg�n la cantidad de caracteres que posee cada nombre.

El nombre con menos letras debe aparecer primero y el nombre con m�s letras al final.

## Restricci�n
No se permite el uso de LINQ.
